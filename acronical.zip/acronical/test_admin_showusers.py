import os, sys, time

from assets.auth.adminFunc import *

AdminFunc.show_all_users()