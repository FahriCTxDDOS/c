import os, sys, time
from assets.auth.crud import *

CRUD.updateUser("root", 5, 5, 5)